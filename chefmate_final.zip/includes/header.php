<?php if (session_status() == PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>ChefMate</title>
</head>
<body>
<nav style="background:#dfe6e9; padding:10px; text-align:center;">
  <a href="index.php">Home</a> |
  <a href="get_recipe.php">Get Recipe</a> |
  <a href="view_recipes.php">View Recipes</a> |
  <?php if (isset($_SESSION['user_id'])) { ?>
    <a href="logout.php">Logout</a>
  <?php } else { ?>
    <a href="register.php">Register</a> |
    <a href="login.php">Login</a>
  <?php } ?>
</nav>
<hr>
