<hr>
<footer style="text-align:center;">© 2025 ChefMate</footer>
</body>
</html>
