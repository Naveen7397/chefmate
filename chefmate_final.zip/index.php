<?php
session_start();
include("includes/header.php");
?>
<h2>Welcome to ChefMate 🍽️</h2>
<p>Your smart recipe recommender and saver system.</p>
<a href="get_recipe.php" style="padding:10px 20px; background:#0984e3; color:white; text-decoration:none;">Get Started</a>
<?php include("includes/footer.php"); ?>
