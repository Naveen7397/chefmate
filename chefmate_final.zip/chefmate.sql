CREATE DATABASE IF NOT EXISTS chefmate;
USE chefmate;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100),
  email VARCHAR(100),
  password VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS saved_recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  title VARCHAR(200),
  ingredients TEXT,
  recipe TEXT
);

INSERT INTO saved_recipes (user_id, title, ingredients, recipe) VALUES
(1, 'Paneer Butter Masala', 'Paneer, Butter, Tomato, Cream, Spices', 'Cook tomatoes, blend, add butter & paneer.'),
(1, 'Chicken Biryani', 'Chicken, Basmati Rice, Spices, Onion, Ghee', 'Marinate chicken, cook with rice and spices.'),
(1, 'Veg Pulao', 'Rice, Mixed Veggies, Spices', 'Cook rice with sautéed vegetables.'),
(1, 'Egg Curry', 'Eggs, Tomato, Onion, Spices', 'Boil eggs, cook in spicy tomato gravy.'),
(1, 'Fish Fry', 'Fish, Chili Powder, Turmeric, Oil', 'Marinate fish & shallow fry.'),
(1, 'Aloo Paratha', 'Potato, Wheat Flour, Spices', 'Stuff potato mix in dough, roll & fry.'),
(1, 'Mutton Curry', 'Mutton, Onion, Tomato, Spices', 'Cook mutton slowly with spices.'),
(1, 'Idli Sambar', 'Idli, Lentils, Tamarind, Spices', 'Make sambar & serve with steamed idlis.'),
(1, 'Masala Dosa', 'Dosa Batter, Potato Masala', 'Cook dosa, fill with potato masala.'),
(1, 'Chicken 65', 'Chicken, Corn Flour, Spices', 'Fry spicy marinated chicken pieces.'),
(1, 'Rasam', 'Tamarind, Tomato, Pepper, Spices', 'Boil tamarind water with spices.'),
(1, 'Pongal', 'Rice, Moong Dal, Pepper, Ghee', 'Cook rice & dal with spices.'),
(1, 'Chole Bhature', 'Chickpeas, Maida, Spices', 'Cook chickpeas curry, serve with fried bhature.'),
(1, 'Pav Bhaji', 'Mixed Vegetables, Pav Buns, Butter', 'Mash veggies in spices, serve with toasted pav.'),
(1, 'Paneer Tikka', 'Paneer, Yogurt, Spices', 'Marinate & grill paneer cubes.'),
(1, 'Gobi Manchurian', 'Cauliflower, Cornflour, Sauces', 'Fry cauliflower & toss in sauces.'),
(1, 'Fried Rice', 'Rice, Veggies, Soy Sauce', 'Stir fry veggies & rice with sauces.'),
(1, 'Veg Kurma', 'Mixed Vegetables, Coconut, Spices', 'Cook veggies in coconut-based curry.'),
(1, 'Chicken Curry', 'Chicken, Onion, Tomato, Spices', 'Cook chicken in onion-tomato gravy.'),
(1, 'Rava Kesari', 'Rava, Sugar, Ghee, Cashews', 'Cook rava with sugar & ghee.');
