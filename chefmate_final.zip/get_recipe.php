<?php
session_start();
include("includes/db.php");
include("includes/header.php");

if (!isset($_SESSION['user_id'])) {
    echo "<p style='color:red; text-align:center;'>Please <a href='login.php'>login</a> to save your recipe.</p>";
    include("includes/footer.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $ingredients = $_POST['ingredients'];
    $recipe = $_POST['recipe'];

    $stmt = $conn->prepare("INSERT INTO saved_recipes (user_id, title, ingredients, recipe) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $title, $ingredients, $recipe);

    if ($stmt->execute()) {
        echo "<p style='color:green; text-align:center;'>🎉 Recipe saved successfully!</p>";
    } else {
        echo "<p style='color:red; text-align:center;'>❌ Failed to save recipe. Please try again.</p>";
    }
}
?>
<h2 style="text-align:center;">ChefMate Recipe Form</h2>
<form method="POST" style="max-width:600px; margin:auto;">
  <label><strong>Recipe Title:</strong></label><br>
  <input type="text" name="title" required style="width:100%; padding:10px;"><br><br>
  <label><strong>Ingredients:</strong></label><br>
  <textarea name="ingredients" rows="5" required style="width:100%; padding:10px;"></textarea><br><br>
  <label><strong>Recipe Steps:</strong></label><br>
  <textarea name="recipe" rows="8" required style="width:100%; padding:10px;"></textarea><br><br>
  <input type="submit" value="Save Recipe" style="padding:10px 20px; background:#27ae60; color:#fff; border:none; cursor:pointer;">
</form>
<?php include("includes/footer.php"); ?>
