<?php
session_start();
include("includes/db.php");
include("includes/header.php");

$result = $conn->query("SELECT title, ingredients, recipe FROM saved_recipes ORDER BY id DESC");

echo "<h2 style='text-align:center;'>🍲 All Available Recipes</h2>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div style='border:1px solid #ccc; padding:15px; margin:10px auto; max-width:700px;'>";
        echo "<h3 style='color:#2c3e50;'>" . htmlspecialchars($row['title']) . "</h3>";
        echo "<strong>Ingredients:</strong><br><pre>" . htmlspecialchars($row['ingredients']) . "</pre>";
        echo "<strong>Steps:</strong><br><pre>" . htmlspecialchars($row['recipe']) . "</pre>";
        echo "</div>";
    }
} else {
    echo "<p style='text-align:center;'>No recipes available yet.</p>";
}

include("includes/footer.php");
?>